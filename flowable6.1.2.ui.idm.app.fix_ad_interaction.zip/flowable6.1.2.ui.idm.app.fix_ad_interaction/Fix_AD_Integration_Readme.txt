
https://forum.flowable.org/t/integration-with-microsoft-active-directory/492/6

Rebuild the idm-app web project after updating FlowableIdmEngineConfiguration 

 ldapConfiguration.setBaseDn(environment.getRequiredProperty("ldap.basedn"));
        //https://forum.flowable.org/t/integration-with-microsoft-active-directory/492/25
        //# Added these 2 lines
        ldapConfiguration.setUserBaseDn(environment.getRequiredProperty("ldap.userbasedn"));
        ldapConfiguration.setGroupBaseDn(environment.getRequiredProperty("ldap.groupbasedn"));

